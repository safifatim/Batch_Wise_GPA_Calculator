document.addEventListener('alpine:init', () => {
    Alpine.data('gpaApp', () => ({
        semester: '',
        year: '',
        courses: [],
        students: [],
        selectedStudent: null,
        currentRid: null,
        searched: false, 

        // 1. Database se unique courses dhondna
        async fetchCourses() {
            if (!this.semester || !this.year) {
                alert("Please select both Semester and Year!");
                return;
            }
            // State resets for new queries
            this.students = [];
            this.selectedStudent = null;
            this.searched = false;
            
            try {
                const response = await fetch(`/api/get-courses?semester=${this.semester}&year=${this.year}`);
                this.courses = await response.json();
                this.searched = true; // Fetch attempt complete
            } catch (error) {
                console.error("Error fetching courses:", error);
                this.searched = true;
            }
        },

        // 2. Kisi dynamic course par click karne par saare students load karna
        async fetchStudents(rid) {
            this.currentRid = rid;
            this.selectedStudent = null;
            try {
                const response = await fetch(`/api/get-students?rid=${rid}`);
                this.students = await response.json();
            } catch (error) {
                console.error("Error fetching students:", error);
            }
        },

        // 3. 0% CSS logical conversion table (Marks to GPA conversion)
        calculateIndividualGPA(student) {
            const marks = parseFloat(student.total_obtained_marks) || 0;
            let gpa = 0.0;
            let grade = 'F';

            // Universal Grade-to-GPA Logic mapping
            if (marks >= 85) { gpa = 4.0; grade = 'A'; }
            else if (marks >= 80) { gpa = 3.66; grade = 'A-'; }
            else if (marks >= 75) { gpa = 3.33; grade = 'B+'; }
            else if (marks >= 71) { gpa = 3.0; grade = 'B'; }
            else if (marks >= 68) { gpa = 2.66; grade = 'B-'; }
            else if (marks >= 64) { gpa = 2.33; grade = 'C+'; }
            else if (marks >= 61) { gpa = 2.0; grade = 'C'; }
            else if (marks >= 58) { gpa = 1.66; grade = 'C-'; }
            else if (marks >= 54) { gpa = 1.30; grade = 'D+'; }
            else if (marks >= 50) { gpa = 1.0; grade = 'D'; }
            else { gpa = 0.0; grade = 'F'; }

            this.selectedStudent = {
                name: student.name,
                regno: student.regno,
                marks: marks,
                gpa: gpa,
                grade: grade
            };
        }
    }));
});