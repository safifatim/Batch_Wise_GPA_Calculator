import { neon } from '@neondatabase/serverless';

export const SQL = neon('postgresql://neondb_owner:npg_J3QyD5wvINeP@ep-icy-lab-at7kepoq-pooler.c-9.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require');