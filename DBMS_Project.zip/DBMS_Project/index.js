import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import batchRoutes from "./routes/batchRoutes.js";

const app = express();
const PORT = 3000;

const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

app.use("/api", batchRoutes);


app.get("/", (req, res) => res.sendFile(path.join(__dirname, "views", "index.html")));

app.listen(PORT, () => console.log(`Express server running at http://localhost:${PORT}`));
