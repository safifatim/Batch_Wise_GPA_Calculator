import express from "express";
import { SQL } from "../utils/db.js";

const router = express.Router();

// 1. Courses list fetch karna Semester aur Year ke base par
router.get("/get-courses", async (req, res) => {
    const { semester, year } = req.query;
    try {
        const result = await SQL`
            SELECT DISTINCT r.rid, c.cid, c.code, c.title 
            FROM recap r
            JOIN course c ON r.cid = c.cid
            WHERE r.semester = ${semester} AND r.year = ${year}
        `;
        res.json(result);
    } catch (error) {
        console.error("Courses DB Error:", error);
        res.status(500).json({ error: error.message });
    }
});

// 2. Kisi Course (RID) ke saare students aur unke aggregated marks uthana
router.get("/get-students", async (req, res) => {
    const { rid } = req.query;
    try {
        // SUM(m.marks) kiya hai taaki Mid, Final, Quiz sab mila kar kul marks mil skein
        const result = await SQL`
            SELECT s.regno, s.name, SUM(m.marks) as total_obtained_marks
            FROM marks m
            JOIN student s ON m.regno = s.regno
            WHERE m.rid = ${parseInt(rid)}
            GROUP BY s.regno, s.name
        `;
        res.json(result);
    } catch (error) {
        console.error("Students DB Error:", error);
        res.status(500).json({ error: error.message });
    }
});

export default router;